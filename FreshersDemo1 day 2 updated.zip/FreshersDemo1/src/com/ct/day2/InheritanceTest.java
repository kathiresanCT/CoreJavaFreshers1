package com.ct.day2;

public class InheritanceTest {

	public static void main(String[] args) {
	Human human1=new Human();
	human1.jump();
	human1.eat();
	human1.walk();
	human1.talk();
	human1.think();
	Primate p=new Primate();
	p.eat();
	p.walk();
	p.jump();
	//p.think();
	//p.talk();
	
	
	
	
	
	}

}
