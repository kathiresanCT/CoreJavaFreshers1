package com.ct.day2;

public class EncapsulationTest {

	public static void main(String[] args) {
	
		Student st=new Student();
		System.out.println(st.studentId);
		//System.out.println(st.password);
		System.out.println("old pwd is :: "+st.getPassword());
		st.setPassword("ajay123");
		System.out.println("new pwd is :: "+st.getPassword());
		System.out.println(st.companyName);
		st.companyName="CITIUSTECH";
		
		Student st1=new Student();
		System.out.println(st1.getPassword());
		System.out.println(st1.companyName);
		
		
		Student stud3=new Student(10001,"ragu");
		System.out.println(stud3);
		System.out.println(stud3.hashCode());
		System.out.println(stud3.getPassword());
		System.out.println(stud3.studentId);
		System.out.println(stud3.companyName);
		stud3=new Student(10001, "raghu");
		System.out.println("now the memory is :: "+stud3);
		System.out.println("now the hashcode is :: "+stud3.hashCode());
		stud3.setPassword("raghu");
		System.out.println("modified pwd is :: "+stud3.getPassword());
		System.out.println(stud3.equals(st));
		
		Student stud4=new Student(10001,"ragu");
		Student stud5=new Student(10001,"ragu");
		//stud4=stud5;
		System.out.println(stud4.equals(stud5));
		System.out.println(stud5);//by default toString()
		System.out.println(stud5.toString());
	}

}

class Student{
	int studentId=0;//default - any class within the pkg com.ct.day2
	private String password="dummy";//default
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(int studentId, String password) {
		this.studentId = studentId;
		this.password = password;
	}
	static String companyName="CT";
	public String getPassword() {
		return password;
	}
	public void setPassword(String pass) {
		this.password = pass;
	}

}


//public String toString() {
//	
//	return getClass().getName()+"@"+Integer.toHexString(hashCode());
//}





