package com.ct.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.ct.dao.EmployeeDaoImpl;
import com.ct.model.Employee;

@Service
public class EmployeeServiceImpl {
	
	@Autowired
	private EmployeeDaoImpl empDao;
	
	public String  addEmployee(Employee emp) {
		return empDao.addEmployee(emp);
	}
	//@Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor=Exception.class)
	public Employee findEmployee(long employeeId) {
		TransactionStatus status = TransactionAspectSupport.currentTransactionStatus();
		System.out.println(status.isNewTransaction());
		return empDao.findEmployee(employeeId);
	}
}
