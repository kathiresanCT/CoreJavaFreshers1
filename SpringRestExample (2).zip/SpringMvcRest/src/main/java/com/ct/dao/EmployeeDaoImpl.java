package com.ct.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ct.model.Employee;

@Repository // @component
public class EmployeeDaoImpl {
	private DataSource ds;
	private JdbcTemplate jdbcTemp;
	@Autowired
	public void setDs(DataSource ds) {
		this.jdbcTemp=new JdbcTemplate(ds);
	}
	
	ArrayList<Employee> empList=new ArrayList<Employee>();
	
	public String addEmployee(Employee emp) {
		//empList.add(emp);
		String sql="insert into employee value(?,?,?,?)";
		jdbcTemp.update(sql,emp.getEmployeeId(),emp.getEmployeeName(),emp.getEmployeeSurname(),emp.getJob());
		return "data of "+emp.getEmployeeName()+" is added";
	}
	@SuppressWarnings("unchecked")
	public Employee findEmployee(long employeeId) {
		String sql="select * from employee where emp_id=?";
		Employee employee=jdbcTemp.queryForObject(sql,new Object[] {employeeId}, new RowMapper()
        {
            public Employee mapRow(ResultSet rs, int rowNum) throws SQLException
            {
                Employee employee = new Employee();
                employee.setEmployeeId(rs.getInt(1));
                employee.setEmployeeName(rs.getString(2));
                employee.setEmployeeSurname(rs.getString(3));
                employee.setJob(rs.getString(4));
                return employee;
            }
        });
		System.out.println(employee);
		return employee;
	}
}
