package com.ct.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ct.model.Employee;
import com.ct.service.EmployeeServiceImpl;
//admin/register

@Controller
//@RequestMapping("admin")
public class SampleController {

	@Autowired
	private EmployeeServiceImpl service;

	@RequestMapping("/")
	public String getHome() {
		return "index";
	}

	@RequestMapping("register")
	public String getLogin(Model mod) {
		Employee emp = new Employee();

		mod.addAttribute("employee", emp);
		return "register";
	}

/*	@RequestMapping(value = "register", method = RequestMethod.POST)
	public String Store(Model m, @ModelAttribute("employee") Employee emp, BindingResult br) {
		if (br.hasErrors()) {
			return "register";
		}
		System.out.println(emp.getEmployeeName() + " " + emp.getJob());
		String msg = service.addEmployee(emp);
		m.addAttribute("msg", msg);
		return "register";
	}

*/	}
