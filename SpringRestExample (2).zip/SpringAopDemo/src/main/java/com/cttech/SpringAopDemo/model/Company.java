package com.cttech.SpringAopDemo.model;

public class Company {

	private int compId;
	private String name;
	
	public Company() {
		// TODO Auto-generated constructor stub
	}

	public Company(int compId, String name) {
		super();
		this.compId = compId;
		this.name = name;
	}

	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Company [compId=" + compId + ", name=" + name + "]";
	}
	
	
	
}
