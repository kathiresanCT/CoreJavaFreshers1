package com.cttech.SpringAopDemo.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

//@Component//to create obj or can put a bean tag in xml
@Aspect
//@Component("loggerAspect")
public class LoggerAspect {

	@Before(value="execution(public String getName())")//where it has to run
	public void loggingAvice() {
		System.out.println("calling aspect logging :: "+System.currentTimeMillis());
		//return 0;
	}
	
	@After(value="execution(public String com.cttech.SpringAopDemo.model.Company.getName())")//where it has to run
	public void loggingAfterAvice() {
		System.out.println("calling aspect logging after :: "+System.currentTimeMillis());
		//return 0;
	}
}
