package com.batch.demo.SpringJdbcSimpleJdbcTemplate;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.stereotype.Component;

@Component("dao")
public class MedicineDaoImpl extends SimpleJdbcDaoSupport {

	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	private void initialize() {
	    setDataSource(dataSource);
	}
	public Medicine getById(int id) {
		String sql="SELECT * FROM Medicine WHERE med_id=?";
		Medicine med=getSimpleJdbcTemplate().queryForObject(sql, ParameterizedBeanPropertyRowMapper.newInstance(Medicine.class), id);
		return med;
	}
	public List<Medicine> getAll(){
		String sql="SELECT * FROM Medicine";
		return getSimpleJdbcTemplate().query(sql, ParameterizedBeanPropertyRowMapper.newInstance(Medicine.class));
		
	}
	
	
}
