package com.batch.demo.SpringWithIOC;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class SmartMobile {

	//@Value("HTC")
	private String mobileName;
	//@Value("10")
	private int version;
	
	public String getMobileName() {
		return mobileName;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
		
	public SmartMobile() {
		//System.out.println("in smart");
	}

	public void videoCall() {
		System.out.println("calling...");
	}
	public SmartMobile(String mobileName, int version) {
		super();
		this.mobileName = mobileName;
		this.version = version;
	}
	public void getAll() {
		System.out.println("in get all");
	}
//	@Override
//	public String toString() {
//		return "SmartMobile [mobileName=" + mobileName + ", version=" + version +" battery "+this.battery+"]";
//	}
//	
}
