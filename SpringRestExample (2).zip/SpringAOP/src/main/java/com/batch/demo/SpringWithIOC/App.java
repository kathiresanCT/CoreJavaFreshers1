package com.batch.demo.SpringWithIOC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring-config.xml");
    	SmartMobile sm=(SmartMobile)ctx.getBean("mobileServiceProxy");
    	System.out.println(sm);
    	sm.getAll();
    	sm.videoCall();
    }
}
