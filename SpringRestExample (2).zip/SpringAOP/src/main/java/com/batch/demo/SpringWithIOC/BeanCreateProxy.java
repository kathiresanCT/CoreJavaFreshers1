package com.batch.demo.SpringWithIOC;

import java.lang.reflect.Method;

import org.springframework.aop.AfterAdvice;
import org.springframework.aop.MethodBeforeAdvice;

import sun.reflect.MethodAccessor;

public class BeanCreateProxy implements MethodBeforeAdvice,AfterAdvice{

	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		System.out.println("before ");
	}

	
	
}
