package com.batch.demo.ui;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.batch.demo.dao.MedicineDaoImpl;
import com.batch.demo.model.Medicine;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
    	MedicineDaoImpl md=(MedicineDaoImpl)context.getBean("MedicineDaoImpl");
    	md.insert(new Medicine(1003,"dolo",33,56.76f));
    	System.out.println("done");
    }
}
