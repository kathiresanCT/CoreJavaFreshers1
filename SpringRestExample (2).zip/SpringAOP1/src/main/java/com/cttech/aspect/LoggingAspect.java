package com.cttech.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LoggingAspect {
	
	@After("execution(public * com.cttech.model.FreeAccount.pay*())")
	public void logAdvice() {
		System.out.println("advice called...");
		//System.out.println("no need to wait....");
		//System.out.println("please subscribe to Premium account!!!");
	}

}
