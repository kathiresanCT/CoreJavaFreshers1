package com.cttech.model;

public class FreeAccount extends Account{

	@Override
	public void register(){
		super.register();
		System.out.println("As Free User!!!");
	}
	public void payFees(){
		int c=1/0;
		System.out.println(c+ " fee paid !!!");
	}
	
	public void payToll(){
		
		System.out.println("toll paid!!!");
	}
	
	public void PayLogin(){
		
		System.out.println("login fee!!!");
	}
	
	
}
