package com.cttech.model;

public class PremiumAccount extends Account{

	@Override
	public void register(){
		super.register();
		System.out.println("As Paid User!!!");
	}
	
	public void payForSubscription(){
		System.out.println("Paid!!! Subscription done!!!");
	}
	
	public void searchForPaidBooks(){
		super.searchForFreeBooks();
		System.out.println("Searching paid books!!!");
	}
}
