package com.cttech.SpringAOP1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cttech.model.Account;
import com.cttech.model.FreeAccount;
import com.cttech.model.PremiumAccount;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
    	 Account  account=(FreeAccount)app.getBean("freeAcc");
    	 //account.register();
    	 FreeAccount f=(FreeAccount)account;
    	 f.payFees();
    	 //f.payToll();
    	// f.PayLogin();
    	/* account=(PremiumAccount)app.getBean("pAcc");//advice method should not be called...here its calling as name matches
    	 account.register();
*/    }
}
