package com.ems.service;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;

public interface Iservice {

	public Employee search_by_id(int id) throws EmployeeException ;
	//public Employee display();
	//public Employee delete_by_id(int id);
}
