package com.ems;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;
import com.ems.service.Iservice;
import com.ems.service.Service;

public class Ui {

	static Logger log = Logger.getLogger(Ui.class);

	public static void main(String[] args) {
		// set level to Info
		log.setLevel(Level.INFO);
		// TODO Auto-generated method stub
		int id = 0;
		Scanner sc = new Scanner(System.in);
		log.info(sc + " is created");
		System.out.println("enter valid id");
		try {
		id = sc.nextInt();
		log.info("user has entered id as " + id);
		Iservice i = new Service();
		log.info("service is being called " + i);
		
			log.info("ID is sent to service to search");
			Employee e = i.search_by_id(id);
			log.info("Employee information found with id : " + id);
			System.out.println(e);
			log.info(e);
		} catch (EmployeeException e) {
			log.error("error occured :: " + e.getMessage());
			System.out.println(e.getMessage());
		}
		catch(InputMismatchException ime) {
		log.error("input is wrong :: "+ime.getMessage());	
		
		}
		
		
	}

}
