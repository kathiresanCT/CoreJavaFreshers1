package com.ems.exception;

public class EmployeeException extends Exception{

	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}
	public EmployeeException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
}
