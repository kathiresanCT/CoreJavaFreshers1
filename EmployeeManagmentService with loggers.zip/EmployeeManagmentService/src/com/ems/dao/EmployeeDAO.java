package com.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;
import com.ems.util.DbUtil;
import com.ems.util.IQueryMapper;

public class EmployeeDAO implements IEmployeeDAO {
	Connection connection=null;
	Employee e = null;
	static Logger log=Logger.getLogger(EmployeeDAO.class);
	
	@Override
	public Employee search_by_id(int id) throws EmployeeException {
		
		try {
			connection=DbUtil.getDbConnection();
			log.info("db is connected successfully "+connection);
			PreparedStatement st = connection.prepareStatement(IQueryMapper.RETRIEVAL_BY_ID);// qry is compiled
			log.info("qry is compiled and ready for placing values");
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			log.info("qry is executed and results has to be iterated");
			if(rs.next()) {
				e=new Employee();
				System.out.println(rs.getString(2));
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setSurname(rs.getString(3));
				e.setJob(rs.getString(4));
			}
			else {
				log.fatal("error occured : employee info not found with id :: "+id);
				throw new EmployeeException("employee not found!!!");
			}
			// System.out.println(rs.getString(3));

		} catch (SQLException s) {
			log.error(s.getMessage());
			throw new EmployeeException("Data not found :: " + s.getMessage());
		}
log.info("data is ready "+e);
		// DriverManager.getConnection(arg, arg1, arg2)
		// TODO Auto-generated method stub
		return e;
	}
}
