package com.ems.dao;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;

public interface IEmployeeDAO {
 public Employee search_by_id(int id) throws EmployeeException ;
}
