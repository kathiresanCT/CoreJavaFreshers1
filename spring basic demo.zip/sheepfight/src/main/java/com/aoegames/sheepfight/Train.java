/**
 * 
 */
package com.aoegames.sheepfight;

public class Train {

	private int trainId=90001;
	private String trainName="Express123";

	public int getTrainId() {
		return trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public Train() {
		// TODO Auto-generated constructor stub
		System.out.println("in constructor");
	}
}
