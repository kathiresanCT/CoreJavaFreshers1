package com.aoegames.sheepfight;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
    //	Train train=new Train();
    	Train train=null;
    	/*BeanFactory beanfact=null;
    	Resource res=new ClassPathResource("springConfig.xml");
    	beanfact=new XmlBeanFactory(res);
    	train=(Train)beanfact.getBean("obj");*/
    	//application context
    	ApplicationContext ctx=null;
    	//ctx=new ClassPathXmlApplicationContext("springConfig.xml");
    /*	train=(Train)ctx.getBean("obj");
    	System.out.println(train);
    	Train train1=(Train)ctx.getBean("obj");
    	System.out.println(train1);
    	Train train2=(Train)ctx.getBean("ob");
    	System.out.println(train2);
    	Train train3=(Train)ctx.getBean("ob1");
    	System.out.println(train3);*/
    	
    	//
    	/*AnnotationConfigApplicationContext ctx1=new AnnotationConfigApplicationContext(Train.class);
    	ctx1.register();
    	ctx1.refresh();
    	Train train4=(Train)ctx1.getBean("hello");
    	System.out.println(train4);*/
    	
    //	System.out.println(train.getTrainId()+" "+train.getTrainName());
    }
}




