/**
 * 
 */
package com.aoegames.sheepfight;

public class Hexagon {

	private int hexId;
	private String hexColor;

	public Hexagon() {
		// TODO Auto-generated constructor stub
	}

	public int getHexId() {
		return hexId;
	}

	public void setHexId(int hexId) {
		this.hexId = hexId;
	}

	public String getHexColor() {
		return hexColor;
	}

	public void setHexColor(String hexColor) {
		this.hexColor = hexColor;
	}
	
}
