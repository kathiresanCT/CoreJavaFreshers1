package com.aoegames.sheepfight;

public class GameGrid {

	private Hexagon hexagon;
	public GameGrid() {
		// TODO Auto-generated constructor stub
	}
	public Hexagon getHexagon() {
		return hexagon;
	}
	public void setHexagon(Hexagon hexagon) {
		this.hexagon = hexagon;
	}
	
	void selectCell(){
		
	}
}
