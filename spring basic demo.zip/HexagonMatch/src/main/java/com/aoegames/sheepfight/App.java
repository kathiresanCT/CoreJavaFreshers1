package com.aoegames.sheepfight;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
    
    	Hexagon hex=null;
    	/*BeanFactory beanfact=null;
    	Resource res=new ClassPathResource("springConfig.xml");
    	beanfact=new XmlBeanFactory(res);
    	train=(Train)beanfact.getBean("obj");*/
    	//application context
    	ApplicationContext ctx=null;
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");
    	/*hex=(Hexagon)ctx.getBean("hexObj");
    	System.out.println(hex.getHexId()+" "+hex.getHexColor());*/
    	GameGrid game=(GameGrid)ctx.getBean("game");
    	System.out.println(game);
    	System.out.println(game.getHexagon());
    	System.out.println(game.getHexagon().getHexId()+" "+game.getHexagon().getHexColor() );
    }
}




