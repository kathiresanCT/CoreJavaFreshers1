/**
 * 
 */
package com.jdbc.model;


public class Customer  {

	private Integer id;
	private String name;
	private String city;
	private String mobile;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Customer(Integer cid, String name, String city, String mobile) {
		super();
		this.id = cid;
		this.name = name;
		this.city = city;
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Customer [cid=" + id + ", name=" + name + ", city=" + city + ", mobile=" + mobile + "]";
	}
	
	

}