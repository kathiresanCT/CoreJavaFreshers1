package com.ems.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ems.exception.EmployeeException;

public class DbUtil {
	public static Connection con = null;
	private static FileInputStream fis=null;
	public static Connection getDbConnection() throws EmployeeException {

		try {
			fis=new FileInputStream("employeeDbConfig.properties");
			Properties prop=new Properties();
			prop.load(fis);
			con = DriverManager.getConnection(prop.getProperty("db.url"),prop.getProperty("db.un"),prop.getProperty("db.pwd"));
		}
		catch (SQLException e) {
			throw new EmployeeException("unable to connect to db :: " + e.getMessage());
		} catch (FileNotFoundException e) {
			throw new EmployeeException(e.getMessage());
		} catch (IOException e) {
			throw new EmployeeException(e.getMessage());
		}
		/*finally {
			if(con!=null) {
				try {
					System.out.println("in finally");
					con.close();
					con=null;
				} catch (SQLException e) {
					throw new EmployeeException("unable to close the connection with DB :: "+e.getMessage());
				}
			}
		}
	System.out.println(con);*/
		return con;
	}
}
