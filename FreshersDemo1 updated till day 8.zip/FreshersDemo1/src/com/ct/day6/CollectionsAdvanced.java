package com.ct.day6;

import java.util.*;

public class CollectionsAdvanced {

	public static void main(String[] args) {
		/*List<String> list=new ArrayList<String>();
		List list1=Arrays.asList("alpha","alpha","beta","catch","the","exception");
		System.out.println(list);
*/		//list.addAll(list1);
	//	list.addAll(arg0, arg1)
		//Collections.sort(list1);
		//System.out.println(list1);
	//	Collections.copy(arg0, arg1);
//		Set newSet=new HashSet();
	//	newSet.add(list1);
	/*	newSet.add("hi");
		newSet.add("hi");
		newSet.add("hi123");
		System.out.println(newSet);
		list1.add(newSet);
	*/	
	//	Collections.sort(newSet);
		//copying list to other list when data is available in both
		
		List<String> list1=new ArrayList<String>();
		list1.add("123");list1.add("234");list1.add("alpha");
		List list2=Arrays.asList("alpha","alpha","beta","catch","the","exception");
		//Collections.nCopies(arg0, arg1)
		Collections.copy(list2, list1);//copies from list1 to list2 ?
		System.out.println("list 1 data "+list1);
		System.out.println("list 2 data "+list2);//replaces first 3 data by list2 elements
		
	}

}
