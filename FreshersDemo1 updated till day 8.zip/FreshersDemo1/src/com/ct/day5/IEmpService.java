package com.ct.day5;

public interface IEmpService {

	public void add(Employee e);
}
