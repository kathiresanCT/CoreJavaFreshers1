package com.ct.day5;

public class EmpDaoImpl implements IEmpDao{

//	Arraylist
	@Override
	public void add(Employee e) {
			
	}

}
