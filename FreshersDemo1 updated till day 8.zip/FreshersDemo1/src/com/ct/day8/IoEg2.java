package com.ct.day8;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class IoEg2 {

	public static void main(String[] args) throws IOException {
		
		//FileReader fn=new FileReader("abc.txt");
		/*BufferedReader br=new BufferedReader(fn);
		String line=br.readLine();
		System.out.println(line);*/
		
		FileWriter fw=new FileWriter("b.txt",true);//creates  the file
		//fw.write("welcome!!!");
		fw.write(" to India");
		fw.append(" hello");
		fw.close();
		/*DataInputStream dis=new DataInputStream(System.in);
		BufferedInputStream bis=new BufferedInputStream(dis);
		int data=dis.read();
		//bis.re
		System.out.println(data);*/
		
		/*InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		int ascii=0;
		while((ascii=isr.read())!=-1) {
			System.out.print((char)ascii);
		}*/
		
		/*String line=br.readLine();
		System.out.println(line);*/
	}

}
