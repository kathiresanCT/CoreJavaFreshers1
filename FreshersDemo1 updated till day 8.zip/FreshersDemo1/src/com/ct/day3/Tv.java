package com.ct.day3;

public class Tv extends Electronics {
	//power on and off methods are inherited from Electronics
}
