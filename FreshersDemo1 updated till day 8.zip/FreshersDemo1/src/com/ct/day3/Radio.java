package com.ct.day3;

public class Radio extends Electronics {
//power on and off methods are inherited from Electronics
	void powerOn() {
		System.out.println("logic changed-powered on...");
	}
	void powerOff() {
		System.out.println("logic is changed-powered off...");
	}
	void changeFreq() {
		System.out.println("freq changed..");
	}
}
