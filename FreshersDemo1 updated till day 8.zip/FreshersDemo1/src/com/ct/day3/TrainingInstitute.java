package com.ct.day3;

public class TrainingInstitute implements IContract1 {

	int balance=0;
	
	@Override
	public void trainingJava() {
		balance=IContract1.NO_OF_DAYS-15;
		System.out.println("java training over "+balance+" left");
	}

	@Override
	public void trainingJsp() {
		balance=balance-15;
		System.out.println("jsp training over "+balance+" left");
	}

}
