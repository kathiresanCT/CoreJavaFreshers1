package com.ct.day3;

public class VarArgsExample {

	public static void main(String[] args) {
	VarArgsExample v=new VarArgsExample();
	//v.getData();
	//v.getData(10);
	//v.getData(1, 2);
	//v.getData(1, 2, 3);
	}
	public void getData(int...a) {
		System.out.println("data "+(a[0]+a[1]+a[2]));
	}
	/*public void getData(int a) {
		System.out.println("data "+a);
	}
	public void getData(int b,int c) {
		System.out.println("data "+c+b);
	}
	public void getData(int a,int b,int c) {
		System.out.println("data "+a+b+c);
	}*/
}
