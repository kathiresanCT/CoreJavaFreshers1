package com.ct.day7;

public class MoneyLessException extends Exception {

	public MoneyLessException() {
		// TODO Auto-generated constructor stub
	}
	public MoneyLessException(String msg) {
		super(msg);
	}
	
}
