package com.ct.day7;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Excep2 {

	public static void main(String[] args) {
		/*Date d=new Date();
		d.getDate();
		System.out.println(d);
		LocalDate l=LocalDate.now();
		l=LocalDate.of(2019, Month.JUNE, 30);
		System.out.println(l);
		System.out.println(l.isLeapYear());
		LocalDateTime ll=LocalDateTime.now();
		System.out.println(ll);
		*/
		
		/*Random rand=new Random();
		int i=rand.nextInt(1000);
		System.out.println(i);
*/
//		System.out.println((int)(Math.random()*1000));
		
		int amt=0;
		amt=new Scanner(System.in).nextInt();
		try {
			check(amt);
		} catch (MoneyLessException e) {
			System.out.println(e.getMessage());
		}
	}
//service
	static void check(int amt) throws MoneyLessException{
		int dbBalance=5000;
		if(amt<dbBalance) {
		//	System.out.println("cannot be less than 500");
			
				throw new MoneyLessException("pls enter amount greater than 500rs");
			
		}
		else {
			System.out.println("withdrawn successfully");
		}
	}
	//modularize
	//getAmount()--use scanner here
	//validateAmt()- chk amt less than 500 here
}
