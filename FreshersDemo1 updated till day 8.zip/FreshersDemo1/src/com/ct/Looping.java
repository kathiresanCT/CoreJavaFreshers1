package com.ct;

public class Looping {

	public static void main(String[] args) {
	
		int i=10;
//		do{
//			System.out.println("hello");
//			i++;
//		}while(i<10);
//		System.out.println(i);
//		while(i<2);
//		{
//			System.out.println("hi");
//		}
		
		int j=1;
		for(;j<=10;)
		{
			System.out.println("hi");
			j++;
		}
		
		int a=6;
		switch(a) //string,int,char,enum----check boolean,float?
		{
		case 1:
		System.out.println("one");
		break;
		case 2:
			System.out.println("two");
			break;
		default:
			System.out.println("enter correct number");
			break;
		case 3:
			System.out.println("three");
			break;
		case 4:
			System.out.println("four");
			break;
		
		case 5:
		case 6:
			System.out.println("its an number");
		break;
		}
		
		
	}

}
