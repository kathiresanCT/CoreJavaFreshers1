package com.ct.day2;

public class Primate {

	private void walk() {
		System.out.println("walks with 2 legs and 2 hands");
	}
	public void jump() {
		System.out.println("jumps!!!");
	}
	public void eat() {
		System.out.println("eating!!!");
	}
}
