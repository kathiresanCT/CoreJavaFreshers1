package com.rest.model;

import java.io.Serializable;

public class EmployeeBean implements Serializable{
	
	private static final long serialVersionUID = 2198896222163489503L;
		private  int id;
		private  String employeeName; 
		private String branch;
		 
		 public EmployeeBean() {
		 super();
		 }

		public EmployeeBean(int id, String employeeName, String branch) {
			super();
			this.id = id;
			this.employeeName = employeeName;
			this.branch = branch;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}

		public String getBranch() {
			return branch;
		}

		public void setBranch(String branch) {
			this.branch = branch;
		}

		@Override
		public String toString() {
			return "EmployeeBean [id=" + id + ", employeeName=" + employeeName + ", branch=" + branch + "]";
		}
		 
}
