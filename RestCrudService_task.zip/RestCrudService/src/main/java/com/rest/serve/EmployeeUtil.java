package com.rest.serve;

import java.util.HashMap;

import com.rest.model.EmployeeBean;

public class EmployeeUtil {
	static HashMap<Integer, EmployeeBean> empList = getEmployeeList();

	public EmployeeUtil() {

		if (empList == null) {
			empList=new HashMap<>();
			EmployeeBean e1=new EmployeeBean(1001,"Aaa","Mumbai");
			EmployeeBean e2=new EmployeeBean(1004,"Bbb","Thane");
			EmployeeBean e3=new EmployeeBean(1009,"Ccc","Pune");
			empList.put(e1.getId(), e1);
			empList.put(e2.getId(), e2);
			empList.put(e3.getId(), e3);
		}
	}

	private static HashMap<Integer, EmployeeBean> getEmployeeList() {
		
		return empList;
	}
	public EmployeeBean getEmplById(int id){
		return getEmployeeList().get(id);
	}
	
}
