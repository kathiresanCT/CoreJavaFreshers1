package com.rest.serve;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.rest.model.EmployeeBean;

@Path("/admin")
public class CrudServices {
	EmployeeUtil serv = new EmployeeUtil();

	@GET
	@Path("/hello")
	// @Produces("text/plain")
	public String sayHello() {
		System.out.println("hi");
		return "hi hello!!!";
	}


	@GET
	@Path("employee/{id}")
    @Produces(MediaType.APPLICATION_JSON)
 public EmployeeBean getEmplById(@PathParam(value = "id") int id)
 {
   EmployeeBean emp=serv.getEmplById(id);
  return emp;
 }
	
	@POST
	@Path("/employee")
    @Consumes(MediaType.APPLICATION_JSON)
 public void addEmp(EmployeeBean emp)
 {
   System.out.println(emp);
  //return emp;
 }
}
