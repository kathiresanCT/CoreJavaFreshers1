package com.ct.dao;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ct.model.Employee;

@Repository // @component
public class EmployeeDaoImpl {

	//ArrayList<Employee> empList=new ArrayList<Employee>();
	@Autowired
	private JdbcTemplate jdbcObj;
	
	public JdbcTemplate getJdbcObj() {
		return jdbcObj;
	}
	public void setJdbcObj(JdbcTemplate jdbcObj) {
		this.jdbcObj = jdbcObj;
	}
	@Transactional
	public String addEmployee(Employee emp) {
	//	empList.add(emp);
		getJdbcObj().update("insert into employee value(?,?,?,?)",new Object[] {Math.random()*1000,emp.getName(),emp.getSurName(),emp.getJob()});
		return "data of "+emp.getName()+" is added";
	}
}
