package com.ct.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.dao.EmployeeDaoImpl;
import com.ct.model.Employee;

@Service
public class EmployeeServiceImpl {
	
	@Autowired
	private EmployeeDaoImpl empDao;
	
	public String  addEmployee(Employee emp) {
		return empDao.addEmployee(emp);
	}
}
