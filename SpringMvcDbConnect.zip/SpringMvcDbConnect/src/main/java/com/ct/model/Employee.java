package com.ct.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Employee {

	private int id;
	@NotEmpty(message="Name is Mandatory")
	@Size(min=3,max=16,message="name should be more than 3 & less than 16")
	private String name;
	@NotEmpty(message="Sur Name is Mandatory")
	@Size(min=3,max=16,message="Sur Name should be more than 3 & less than 16")
	private String surName;
	private String job;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Employee(int id, String name, String surName, String job) {
		super();
		this.id = id;
		this.name = name;
		this.surName = surName;
		this.job = job;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", sur name=" + surName + ", job=" + job + "]";
	}
	
}
