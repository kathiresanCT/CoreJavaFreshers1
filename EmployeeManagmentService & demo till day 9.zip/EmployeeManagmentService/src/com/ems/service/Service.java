package com.ems.service;

import com.ems.dao.EmployeeDAO;
import com.ems.dao.IEmployeeDAO;
import com.ems.exception.EmployeeException;
import com.ems.model.Employee;

public class Service implements Iservice{
	public Employee search_by_id(int id) throws EmployeeException {
		IEmployeeDAO e = new EmployeeDAO();
		
		return e.search_by_id(id);
	}

}
