package com.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;

public class EmployeeDAO implements IEmployeeDAO{
@Override
public Employee search_by_id(int id) throws EmployeeException {
	Employee e = new Employee(); 
	try {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
		String qry="SELECT * FROM Employee WHERE emp_id=?";
		//System.out.println(qry);
		//Statement st= con.createStatement();
		PreparedStatement st=con.prepareStatement(qry);//qry is compiled
		st.setInt(1,id);
		ResultSet rs=st.executeQuery();
		
		if(rs.next())
		{
			e.setId(rs.getInt(1));
			e.setName(rs.getString(2));
			e.setSurname(rs.getString(3));
			e.setJob(rs.getString(4));


		}
		//System.out.println(rs.getString(3));
	 
	 
	 } catch (SQLException s) {
		throw new EmployeeException("connection not established" +s.getMessage());
	}  

	//DriverManager.getConnection(arg, arg1, arg2)
	// TODO Auto-generated method stub
	return e;
}
}
