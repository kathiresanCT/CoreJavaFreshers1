package com.ems;
import java.util.*;

import com.ems.exception.EmployeeException;
import com.ems.model.Employee;
import com.ems.service.Iservice;
import com.ems.service.Service;
public class Ui {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int id=0;
   Scanner sc = new Scanner(System.in);
  
   System.out.println("enter valid id");
   id = sc.nextInt();
   Iservice i = new Service();
   try {
	Employee e = i.search_by_id(id);
	System.out.println(e);
} catch (EmployeeException e) {
	System.out.println(e.getMessage());
	}
   
   
	}

}
