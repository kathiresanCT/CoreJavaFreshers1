package com.ct.day3;

public class Company {

	public static void main(String[] args) {
		IContract1 t=new TrainingInstitute();
		t.trainingJava();
		t.trainingJsp();

		t=new NIIT();
		t.trainingJava();
		t.trainingJsp();
	}

}
