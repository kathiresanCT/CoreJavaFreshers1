package com.ct.day3;

public class TestPoly {

	public static void main(String[] args) {
		//dynamic method dispatch
		Electronics elec=null;
		elec=new Radio();
		elec.powerOn();
		elec.powerOff();//calls the method in base
		Radio r=null;
		if(elec instanceof Radio) {
		r=(Radio)elec;//down casting
		r.changeFreq();
		}
		else {
		Tv t=(Tv)elec;
		//unique method of tv class
		}
		
		System.out.println(elec instanceof Object);
		System.out.println(elec instanceof Electronics);
		System.out.println(elec instanceof Radio);
		System.out.println(r instanceof Object);//true
		System.out.println(r instanceof Radio);//true
		System.out.println(r instanceof Electronics);//true
	}

}
