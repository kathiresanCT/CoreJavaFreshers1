package com.ct.day5;

public abstract class Employee {
	int id;
	String name;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int id,String name) {
		this.id=id;
		this.name=name;
	}
	abstract void work();

}


class Admin extends Employee{
	int items;
	public Admin() {
		// TODO Auto-generated constructor stub
	}
	public Admin(int id,String name,int items) {
		super(id,name);
		this.items=items;
		
	}
	
	
	@Override
	void work() {
	System.out.println("managing inventory");
		
	}
	//display()
}
//a class may or may not have abstract method can be marked as abstract class
//if a class contains 1 abstract method should be marked as abstract 
//if a sub class inherits abstract class , it should override all abstract methods or 
//make sub class also as abstract
//cannot create a object for abstract but reference can be created
//it can have constructors, used for initializing base class variables