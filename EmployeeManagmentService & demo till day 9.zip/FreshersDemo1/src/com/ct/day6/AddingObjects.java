package com.ct.day6;

import java.util.*;

public class AddingObjects {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) {
		/*Car car=new Car();
		Set setData=new HashSet();
		setData.add(car);
		setData.add(car);
		System.out.println(setData);
		System.out.println("size of set "+setData.size());
		setData.add(new Car());
		setData.add(new Car());
		System.out.println(setData);
		System.out.println("size of set "+setData.size());
		
		Set<String> data=new HashSet<String>();
		data.add("hello");
		*/
		//set to hold objects of vehicle only
		
		Set<? super Vehicle> data=new HashSet<Vehicle>();
		data.add(new Car());
		data.add(new Bus());
		Iterator it=data.iterator();
		data.add(new Vehicle());
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println(data.size());
		display(data);
	}
	
	public static void display(Set<? super Vehicle> obj) {
		System.out.println(obj);
		//task
		//list<String>
		//list l;//boolean char float
	}

}

class Vehicle{
	
}
class Car extends Vehicle{
	
}
class Bus extends Vehicle{
	
}
