/**
 * 
 */
package com.jdbc.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jdbc.model.Employee;

public class EmployeeDao {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int saveEmployee(Employee e) {
		String query = "insert into employee values('" + e.getId() + "','" + e.getName() + "','" + e.getSalary() + "')";
		return jdbcTemplate.update(query);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Employee> getAllEmployee() {

		String sql = "SELECT name,salary,id FROM Employee";
		List<Employee> lstEmployees = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Employee.class));
		return lstEmployees;
	}

	/*public Employee getById(int id) {
		Employee emp=null;
		String sql="SELECT name,salary,id FROM Employee where id="+id;
		emp=(Employee) jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper(Employee.class));
		return emp;
	}*/
	public Employee getById(int id) {
		Employee emp=null;
		String sql="SELECT name,salary,id FROM Employee where id=?";
		emp=(Employee) jdbcTemplate.queryForObject(sql,new Object[]{id},new BeanPropertyRowMapper(Employee.class));
		return emp;
	}
	
	public int getSalaryByName(String name) {
		int id=0;
		String sql="SELECT id FROM Employee where name=?";
		id=jdbcTemplate.queryForInt(sql,new Object[]{name});
		return id;
	}
}
