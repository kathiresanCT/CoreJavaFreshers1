package com.jdbc.service;

public interface IEmployeeService {

}
