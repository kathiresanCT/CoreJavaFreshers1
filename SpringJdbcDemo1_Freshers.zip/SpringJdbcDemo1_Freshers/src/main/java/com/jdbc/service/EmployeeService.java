/**
 * 
 */
package com.jdbc.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


public class EmployeeService {

	
}
