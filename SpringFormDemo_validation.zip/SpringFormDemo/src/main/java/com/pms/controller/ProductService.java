package com.pms.controller;

import org.springframework.stereotype.Service;

@Service("myserv")
public class ProductService {

}
