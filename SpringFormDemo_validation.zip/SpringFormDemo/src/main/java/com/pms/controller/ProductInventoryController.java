package com.pms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pms.model.Product;

@Controller
public class ProductInventoryController {

	@Autowired
	/*@Qualifier("myserv")*/
	private ProductService pserv;
	
	public ProductInventoryController() {
System.out.println("controller obj created");

}
	@RequestMapping("/")
	public String getHomePage(){
		return "home";
	}
	@RequestMapping("/addProduct.do")
	public String addProductPage(Model m){
		Product p=new Product();
		m.addAttribute("prod",p);
		return "add";
	}
	
	@RequestMapping(value="/store",method=RequestMethod.POST)
	public String storeProductInDb(@Valid @ModelAttribute("prod") Product product,BindingResult br){
		if(br.hasErrors()) {
			System.out.println(br);
			return "add";
		}
		else {
			System.out.println(product.getPrice()+" "+product.getProdName());
				
		}
		return "home";
	}
}
