package com.ct.day2;

import com.ct.*;

public class Annotation {
Admin ad=new Admin();
}
class A{
	
}
class B extends A
{
	//@Override	
	public void display() {
		
	}
}

