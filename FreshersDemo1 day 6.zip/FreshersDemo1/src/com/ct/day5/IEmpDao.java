package com.ct.day5;

public interface IEmpDao {
	public void add(Employee e);
}
