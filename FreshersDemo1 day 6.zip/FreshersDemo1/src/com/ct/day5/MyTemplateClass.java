package com.ct.day5;

public class MyTemplateClass {

	public static void main(String[] args) {
		Template<Integer> tt=new Template();
		System.out.println(tt.display(1990));
//get inpu from user 
		Employee ee=new Employee();
		IEmpService serv=null;
		serv=new EmpServiceImpl();
		serv.add(ee);
		
	}

}
class Template<T>{
	T a;
	public T display(T b) {
		a=b;
		System.out.println(a);
		return a;
	}
}




