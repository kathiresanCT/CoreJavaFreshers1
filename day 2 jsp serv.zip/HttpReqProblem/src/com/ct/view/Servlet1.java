package com.ct.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/s1")
public class Servlet1 extends HttpServlet {
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//get data and print
		//generate link to serv 2
		resp.setContentType("text/html");
		String id=req.getParameter("id");
		String price=req.getParameter("price");
		String name=req.getParameter("name");
		HttpSession session=req.getSession(true);//recommended to use if
		session.setMaxInactiveInterval(12);
		//session created for 1st time
//		HttpSession session=req.getSession(false); gives null //handle NPE
//		HttpSession session=req.getSession();//this will not force server to create session obj
		session.setAttribute("id", id);
		session.setAttribute("name", name);
		session.setAttribute("price", price);
		out=resp.getWriter();
		//out.println(finalData);
		out.println("<a href='s2'>click for serv 2</a>");
		
		
		
	}
}