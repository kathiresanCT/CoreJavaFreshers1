package com.aoegames.sheepfight;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
   
    	Train train=null;
    
    	//application context
    	ApplicationContext ctx=null;
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");
    	train=(Train)ctx.getBean("obj");
    	System.out.println(train);
    	System.out.println(train.getTrainId());
    }
}




