/**
 * 
 */
package com.aoegames.sheepfight;

public class Train {

	private int trainId;
	private String trainName;
	private int noOfComp;
public int getNoOfComp() {
	return noOfComp;
}
	public int getTrainId() {
		return trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
//int a -- const(a,no,name)
	public Train() {
		// TODO Auto-generated constructor stub
		System.out.println("in constructor");
	}
	public Train(int trainId, String trainName, int noOfComp) {
		
		this.trainId = trainId;
		this.trainName = trainName;
		this.noOfComp = noOfComp;
	}
	public Train( String trainName) {
		System.out.println("in string arg");
		this.trainName = trainName;
	}
	public Train(int trainId) {
		System.out.println("in int arg");
		this.trainId = trainId;
		
	}
	
}
