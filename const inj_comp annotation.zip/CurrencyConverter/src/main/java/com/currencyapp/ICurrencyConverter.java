package com.currencyapp;

public interface ICurrencyConverter {

	public abstract void convertDollarToRupees(int dollar);
	
}