/**
 * 
 */
package com.currencyapp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component//("currency")
//@Scope(value="prototype")
public class CurrencyConverter implements ICurrencyConverter {
	@Value("899")
	private int dollar;
public int getDollar() {
	return dollar;
}
	@Override
	public void convertDollarToRupees(int dollar) {
		this.dollar=dollar;
		System.out.println(this.dollar*71);
		
	}
	
	

}