package com.currencyapp;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
    
    	ApplicationContext ctx=null;
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");
    	ICurrencyConverter ic=(CurrencyConverter)ctx.getBean("currencyConverter");
    	System.out.println(ic);
    	ICurrencyConverter ic1=(CurrencyConverter)ctx.getBean("currencyConverter");
    	System.out.println(ic1);
    	System.out.println(((CurrencyConverter)ic).getDollar());
    	ic.convertDollarToRupees(10);
    }
}




