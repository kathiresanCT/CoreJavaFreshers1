package com.ct.msa.dao;

import java.util.ArrayList;

import com.ct.msa.model.Mobile;

public class MobileDaoImpl implements IMobileDAO{

	ArrayList<Mobile> list=new ArrayList<Mobile>();
	
	public void addMobile(Mobile m) {
		
		list.add(m);
	}

	public void deleteMobile(int mId) {
		// TODO Auto-generated method stub
		
	}

	
	public void updateMobileDetails(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		// TODO Auto-generated method stub
		
	}

}
